#include <iostream>

using namespace std;

template<class var>
void print(var line){
cout << line;
}

//prototypes

int inputInt(string show);
string inputStr(string show), lower(string line);
void inputArray(),createArray(), engine(), commands();


//globals
const int row = 5;
const int column = 2;
int numsContainer[row][column];


int main()
{
    print("\n##################################################################");
    print("\n################          Array Builder         ##################");
    print("\n##################################################################\n\n");

    commands();

    createArray();
    engine();

    return 0;
}

void createArray(){

    print("\n\nArray Input\n\n");
    //you can change the row value and the column value here..
    //but am using the default  :: row 5, column 2
    inputArray();
}


void printArray(){
    print("\nArray : \n");
    for (int i=0;i<row;i++){
        for (int j=0;j<column;j++){
            cout << "["<<i<<"]["<<j<<"] : " << numsContainer[i][j] << "\t";
        }
        print("\n");
    }
}

void inputArray(){
    for (int i=0;i<row;i++){
        for (int j=0;j<column;j++){
            cout << "Enter value for ["<<i<<"]["<<j<<"] : ";
            numsContainer[i][j] = inputInt("");
        }
        print("\n");
    }
}


void _insert(){
    int r = inputInt("enter row index    : ");
    int c = inputInt("enter column index : ");
    if (r > row-1){
        print("\ninvalid row index");
    }
    else if (c > column-1){
        print("\ninvalid column index");
    }
    else{
        int value = inputInt("enter a value : ");
        numsContainer[r][c] = value;
    }
}


void _remove(){
    int nextNum;
    bool startRearranging = false;
    int r = inputInt("enter row index    : ");
    int c = inputInt("enter column index : ");
    if (r > row-1){
        print("\ninvalid row index");
    }
    else if (c > column-1){
        print("\ninvalid column index");
    }
    else{
        for (int i=0;i<row;i++){
            for (int j=0;j<column;j++){
                if (r == i && c == j){
                    startRearranging = true;
                }
                if (startRearranging){
                    try{
                        if (j < column-1){
                            nextNum = numsContainer[i][j+1];
                        }
                        else{
                            nextNum = numsContainer[i+1][0];
                        }
                        numsContainer[i][j] = nextNum;
                    }
                    catch(...){
                        numsContainer[i][j] = NULL;
                    }
                }
            }
        }
        printArray();
    }
}

void commands(){
    print("\ninsert   or i  ----------- insert an element to an index");
    print("\nremove   or r  ----------- remove an element to an index");
    print("\ncommands or c  ----------- show available commands");
    print("\nprint    or p  ----------- print array elements");
    print("\nquit     or q  ----------- end the program");
}

void engine(){
    //loop to input clear remove elements
    cin.clear();
    string command = lower(inputStr("\n\nEnter A Command >>>> "));
    if (command == "commands" || command == "c"){
        commands();
        engine();
    }
    else if (command == "insert" || command == "i"){
        _insert();
        engine();
    }
    else if (command == "remove" || command == "r"){
        _remove();
        engine();
    }
    else if (command == "print" || command == "p"){
        printArray();
        engine();
    }
    else if (command == "quit" || command =="q"){
        print("\nProgram exited...");
        //pass to exit.
    }
    else{
        print("invalid command..");
        engine();
    }
}


int inputInt(string show){
    cin.clear();
    if (show == ""){
        //nothing
    }
    else if (show == "default"){
        print("Enter a value : ");
    }
    else{
        print(show);
    }
    int value;
    cin >> value;
    while (cin.fail()){
        cin.ignore();
        return inputInt("( invalid input ) please enter a number : ");
    }
    return value;
}


string inputStr(string show){
    cin.clear();
    if (show == ""){
       //
    }
    else if (show == "default"){
        print("Enter a value : ");
    }
    else{
        print(show);
    }
    string value;
    cin >> value;
    return value;
}


string lower(string line){
    string LOWER = "abcdefghijklmnopqrstuvwxyz";
    string UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    string ret_lower = "";
    int len = line.length();
    for (int i=0;i<len;i++){//boy
        for (int j=0;j<26;j++){
            if (line[i] == UPPER[j]){
                ret_lower += LOWER[j];
                break;
            }
            else if (j == 25){
                ret_lower += line[i];
            }
        }

    }
    return ret_lower;
}
