#include <iostream>
#include <vector>
using namespace std;

void bubbleSort(int[], int);
void selectionSort(int[], int);
void printArray(int[], int);

template <class var>
void print(var line){cout << line;}



int main(){

    //normal arrays
    int arr[] = {5,8,34,25,87,14,2,6,45,45,78,2,34};
    int length = sizeof(arr)/sizeof(arr[0]);

    bubbleSort(arr, length);
    selectionSort(arr, length);

    return 0;
}

int getSmallestIndex(int arr[], int length, int start_from){
    int minIndex = start_from;
    for (int i=start_from;i<length-1;i++){
        if (arr[i] < arr[minIndex]){
            minIndex = i;
        }
    }
    return minIndex;
}

void selectionSort(int arr[], int length){
    int i, smallestIndex, temp;
    for (i = 0;i < length-1; i++){
        int smallestIndex = getSmallestIndex(arr, length, i);
        temp = arr[smallestIndex];
        arr[smallestIndex] = arr[i];
        arr[i] = temp;
    }
    printArray(arr, length);
}


void bubbleSort(int arr[], int length){
    int temp, iteration, index;
    for (iteration = 1; iteration < length; iteration++){
        for (index = 0; index < length - iteration; index++){
            if (arr[index] > arr[index + 1]){
                //swapping
                temp = arr[index];
                arr[index] = arr[index + 1];
                arr[index + 1] = temp;
            }
        }
    }
    printArray(arr, length);
}


void printArray(int _array[], int length){
    print("\n");
    for (int i = 0; i < length; i++) {
        print(_array[i]);print(" ");
        if ((i + 1) % 10 == 0){
            print("\n");
        }
    }
}
